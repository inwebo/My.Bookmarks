<!-- About -->
<div class="grid_12">

    <h2>Readme</h2>
    <pre>
        <?php

            $contenu=file_get_contents('README');
            echo $contenu;
        ?>
    </pre>

</div>
<!-- About -->
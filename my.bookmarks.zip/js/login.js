(function($){
	$('#loginContainer').hide();
	$('#loginClick').click(function() {
		$('#loginContainer').fadeToggle('fast');
                $( this ).parent().toggleClass('heaederListActif');
	});
})(jQuery)

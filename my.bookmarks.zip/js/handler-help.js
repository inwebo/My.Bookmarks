(function($){

$('.containerHelp');

$('#displayHelp a').click (function(){
    
});

})(jQuery)

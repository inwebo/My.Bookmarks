<?php
/**
 * My.Framworks
 *
 * LICENCE
 *
 * Vous �tes libre de :
 *
 * Partager : reproduire, distribuer et communiquer l'oeuvre
 * Remixer  : adapter l'oeuvre 
 *
 * Selon les conditions suivantes :
 *
 * Attribution : Vous devez attribuer l'oeuvre de la mani�re indiqu�e par 
 * l'auteur de l'oeuvre ou le titulaire des droits (mais pas d'une mani�re
 * qui sugg�rerait qu'ils vous soutiennent ou approuvent votre utilisation 
 * de l'oeuvre). 
 *
 * Pas d�Utilisation Commerciale : Vous n'avez pas le droit d'utiliser cette
 * oeuvre � des fins commerciales. 
 *
 * Partage � l'Identique : Si vous modifiez, transformez ou adaptez cette
 * oeuvre, vous n'avez le droit de distribuer votre cr�ation que sous une
 * licence identique ou similaire � celle-ci.
 *
 * Remarque : A chaque r�utilisation ou distribution de cette oeuvre, vous 
 * devez faire appara�tre clairement au public la licence selon laquelle elle
 * est mise � disposition. La meilleure mani�re de l'indiquer est un lien vers
 * cette page web. 
 *
 * @category  My.Framworks
 * @package   Base
 * @copyright Copyright (c) 2005-2011 Inwebo (http://www.inwebo.net)
 * @author    Julien Hannotin
 * @license   http://creativecommons.org/licenses/by-nc-sa/2.0/fr/
 * @version   $Id:$
 * @link      https://github.com/inwebo/My.MVC
 * @since     File available since Beta 28-11-2011
 */
?>
<?php
/**
 * Manipulation de ligne de fichier texte
 *
 * Manipulation de ligne de fichier texte brut, permet la suppression de ligne, l'ajout au milieu du fichier
 * en d�but de fichier, � la fin. Par extensions nous nommerons tous les fichiers en texte brut par log.
 *
 * Un objet log est pour cette class tous fichiers texte brut. Un objet log est compos� de n lignes avec
 * chaque ligne d�limit�e par un retour chariot.
 * Un objet log peut �tre compos� de un ou plusieurs fichier texte brut ayant un patron commun, pr�fix�
 * par un indice num�rique.
 * Un objet log a une taille maximum en octet, si le buffer d�passe cette taille plusieurs fichiers se-
 * -ront utilis�s lors de la sauvegarde
 *
 * Exemple
 * 		00-fichier.log
 *		01-fichier.log
 *		02-fichier.log
 *		03-Autrefichier.log
 *
 *		Les trois premi�res lignes d�signent le m�me objet log avec comme patron commun "fichier"
 *		La derni�re ligne est un autre objet log son patron est "Autrefichier"
 *
 *
 * Lors de l'instanciation de la classe, cr�er le fichier contenant le log si il n'existe pas. Si l'objet
 *  existe d�j� et est compos� de plusieurs fichier alors chargement de celui avec le plus grand indice
 * num�rique.
 *
 * Chaque ligne du fichier �tant une entr�e dans le tableau buffer. Les manipulations se font toujours
 * au niveau du buffer, aucune modification au fichier n'est faite jusqu'� la sauvegarde gr�ce �
 * la m�thode save();.
 *
 *
 *
 * @author	   Inwebo
 * @copyright  Inwebo
 * @license    http://creativecommons.org/licenses/by-nc-sa/2.0/fr/
 * @version    09-2011
 * @link
 * @since      Juin 2010
 */

/**
 * Constantes d'environnement
 */
define( 'UNIX', 'UNIX' );
define( 'WINDOWS', 'WINDOWS' );
define( 'MAC_OS', 'MAC_OS' );

/**
 * Constantes de positionnement
 */
define( 'NEXT', 'NEXT' );
define( 'PREV', 'PREV' );
define( 'FIRST', 'FIRST' );
define( 'LAST', 'LAST') ;

/**
 * Constantes d'erreurs
 */
define( 'ERROR_LINE', 'Choosen line is out of range');


// Envoi par mail du buffer = Alerte par mail
// Compress� le log

class MyLog {

	/**
	 * Manipulation de ligne de fichier texte
	 *
	 *
	 * @arguments  STRING $filePath		 	: Chemin d'acces au ficher texte � parser
	 * 			   CONST  $os	 			: Choix de l'os qui manipulera les fichiers, c'est cette variable
	 *										  qui fixera les caracteres de fin de ligne
	 *			   BOOL	  $truncate			: 1 Si la sauvegarde du fichier est faite, la taille maximum de celui ci
	 * 										  sera de $size octets
	 *			   INT	  $size				: Taille en octets que le fichier sauvegard� fera au maximum si la
	 *										  taile du buffer depace celle de $size alors autant de fichier que
	 *										  n�cessaire seront cr�es.
	 *
	 * @return     VOID
	 */
	public function __construct( $filePath = 'logs.log', $truncate = 1, $size = 1048576 ) {

		if( !file_exists( $filePath ) ) {
				if( fopen( $filePath, "a+" ) === FALSE) {
					throw new exception("<strong>ERROR</strong> : File $filePath doesn't exist");
				}
		}

		$this->end 		= $this->setLineEnd();

		if( $truncate === true || $truncate == "1" ) {
			$this->truncate = $truncate;
		}
		else {
			trigger_error("<strong>$truncate</strong> is not a bool ", E_USER_ERROR);
		}

		if( is_int( $size ) ) {
			$this->size	= $size;
		}
		else {
			trigger_error("<strong>$size</strong> is not a numeric value");
		}

		$this->file		= $filePath;
		$this->Content 	= file( $this->file );
		$this->Buffer	= $this->setNatural( $this->Content );

	}


	/**
	 * Choisis le retour � la ligne selon l'os.
	 * Par defaut renvois le retour chariot WINDOWS
	 *
	 * @arguments  VOID
	 *
	 *
	 * @return     	STRING 	$endLine 	"\n"   : Pour Les systemes Unix, Linux
	 *									"\r\n" : Pour les systems Windows  ( DEFAULT )
	 *					 				"\r"   : Pour MacOS
	 */
	private function setLineEnd() {
		$endLine = "";
		switch ( strtolower(PHP_OS) ) {

			default:
			case 'linux':
			case 'unix':
				$endLine = "\n";
				break;

			case 'windows':
				$endLine = "\r\n";
				break;

			case 'mac':
				$endLine = "\r";
				break;
		}
		return $endLine;
	}

	/**
	 * Pour une manipulation plus naturelle des lignes, nous commencons � les compt�es � 1
	 * dans le tableau $array
	 *
	 * @arguments   VOID
	 *
	 *
	 * @return     	ARRAY 		$temp	: Tableau num�rique commencant � l'index 1
	 *				EXCEPTION			: Si $array n'est pas un tableau
	 */
	private static function setNatural( $array ) {
		if( !is_array( $array ) ) {
			throw new Excepetion ("Arg : $array is not an array !");
		}
		$temp 		= array();
		$compteur 	= 1;
		foreach( $array as $key => $value ) {
			$temp[ $compteur ] = trim($value);
			++$compteur;
		}
		return $temp;
	}

	/**
	 * Retourne le contenu du fichier log courant.
	 * voir la fonction file ( http://php.net/manual/fr/function.file.php )

	 * @arguments   VOID
	 *
	 *
	 * @return     	ARRAY 	$this->Content
	 */
	public function getLogs() {
      return $this->Content;
	}

	/**
	 * Retourne le contenu de la ligne $lineNumber contenue dans le tableau numerique Buffer
	 *
	 * @arguments  INT $lineNumber : Le num�ro de ligne voulue
	 *
	 *
	 * @return     STRING 		$content : La ligne de texte $linenumber
	 *			   EXCEPTION		     : Si $lineNimber n'est pas contenue dans le tableau
	 */
	public function getLine( $lineNumber ) {
		if( !$this->isLine( $lineNumber ) ) {
			throw new Exception( ERROR_LINE );
		}
		$content = $this->Buffer[ $lineNumber ];
		return $content;
	}

	/**
	 * Remplace la ligne $ligneNumber avec le texte $text
	 *
	 * @arguments  INT		$lineNumber : Le num�ro de ligne voulue
	 *			   STRING	$text 		: Le texte de remplacement
	 *
	 *
	 * @return     STRING 	$content 	: La ligne de texte $linenumber
	 */
	public function setLine( $lineNumber, $text ) {
		return  $this->Buffer[ $lineNumber ] = utf8_encode( $text );
	}

	/**
	 * Ajoute une ligne � l'emplacement $at, ayant pour texte la valeure $text, $flag indique
	 * la methode d'insertion � utiliser
	 *
	 * @arguments  INT 	  $at 	: Le num�ro de ligne voulue
	 *			   STRING $text : Le texte de remplacement
	 *			   CONST  $flag : PREV avant la ligne $at
	 * 							  NEXT apres la ligne $at
	 *							  FIRST au debut du fichier
	 *							  LAST	a la fin du fichie
	 *
	 *
	 * @return     STRING $content La ligne de texte $linenumber
	 */
	//public function addLine( $at, $text, $flag = LAST ) {
	public function addLine( $text, $at = NULL, $flag = LAST ) {
		if(abs($at) > $this->getTotalLines( $this->Buffer )) {
			throw new Exception (ERROR_LINE);
		}
		switch ( $flag ) {
			default:
			case LAST:
				array_push( $this->Buffer, $text );
				break;

			case FIRST:
				array_unshift( $this->Buffer, $text );
				break;

			case PREV:
				$left  = array_slice( $this->Buffer, 0, $at - 1 );
				$right = array_slice( $this->Buffer, $at - 1 );
				array_push( $left, $text );
				$this->Buffer = array_merge( $left,$right );
				break;

			case NEXT:
				$left = array_slice( $this->Buffer,0, $at );
				$right = array_slice( $this->Buffer, $at );
				array_push( $left, $text );
				$this->Buffer = array_merge( $left,$right );
				break;
		}
		$this->Buffer = $this->setNatural( $this->Buffer );
	}

	public function firstLine($text) {
		array_unshift( $this->Buffer, $text );
	}

	public function line( $text ) {
		array_push( $this->Buffer, $text );
	}

	/**
	 * Supprime la ligne $lineNumber
	 *
	 * @arguments  INT 	  	$lineNumber 	: Le num�ro de ligne � effacer
	 *
	 *
	 * @return     STRING 	$content		: La ligne de texte $linenumber
	 */
	public function delLine( $lineNumber ) {
		if( !self::isLine( $lineNumber ) ) {
			throw new Exception(ERROR_LINE);
		}
		unset( $this->Buffer[ $lineNumber ] );
		$this->Buffer = $this->setNatural( $this->Buffer );
		return 1;
	}

	/**
	 * Enregistre le buffer courant dans une fichier $file
	 *
	 * @arguments  STRING $file 	: Chemin d'acc�s � un fichier
	 *
	 *
	 * @return     STRING $content 	: La ligne de texte $linenumber
	 */
	public function save() {
		if ( !is_writable( $this->file ) && !fopen( $this->file , "w" ) ) {
			throw new Exception("$this->file is not writable");
		}
		$string   = "";
		$compteur = 1;
		foreach( $this->Buffer as $value ) {
			if( $compteur === $this->getTotalLines() ) {
				$string.= trim( $value ) ;
			}
			else {
				$string.= trim( $value ) . $this->end;
			}
			++$compteur;
		}
		$fp = fopen( $this->file, 'w+' );
		fwrite( $fp, utf8_encode ( $string ) );
		fclose( $fp );
	}

	/**
	 * Reset du buffer
	 *
	 * @arguments  VOID
	 *
	 *
	 * @return     VOID
	 */
	public function reset() {
		$this->Buffer = array();
	}


	/**
	 * Retourne le nombre de ligne contenues dans le buffer courant
	 *
	 * @arguments  VOID
	 *
	 *
	 * @return     INT nombre de ligne
	 */
	public function getTotalLines() {
		return count( $this->Buffer );
	}


	/**
	 * Retourne le buffer courant sous forme de tableau
	 *
	 * @arguments  VOID
	 *
	 *
	 * @return     ARRAY $this->Buffer	: voir la fonction file ( http://php.net/manual/fr/function.file.php )
	 */
	public function getBuffer() {
		return $this->Buffer;
	}

	/**
	 * Retourne le buffer courant sous forme de chaine de caracteres
	 *
	 * @arguments  VOID
	 *
	 *
	 * @return     STRING $temp		: Tous les elements du tableau concat�n� dans une chaine de caractere
	 */
	public function __toString() {
		$temp ="";
		foreach($this->Buffer as $value) {
			$temp .= $value . $this->end;
		}
		return $temp;
	}

	/**
	 * Renvois la taille en octet du buffer.
	 *
	 * @arguments  VOID
	 *
	 *
	 * @return     INT Taille totale en octet du buffer
	 */
	public function getBufferSize() {
		$size =$this->getBufferAsString();
		return mb_strwidth($size);
	}

	/**
	 * Retourne la taille en octets du fichier log
	 *
	 * @arguments  VOID
	 *
	 *
	 * @return     INT	: Taille en octet du fichier log
	 */
	public function getFileSize($file = 'copy.log') {
		return filesize($file);
	}

	/**
	 * Test si le numero de ligne $int est une ligne disponible du tableau Buffer
	 *
	 * @arguments  VOID
	 *
	 *
	 * @return     BOOL 0 si la ligne n'est pas contenue dans le tableau
	 *			   BOOL 1 si la ligne est contenu dans le tableau
	 */
	private function isLine( $int ) {
		if( !is_int( $int ) ) {
			trigger_error("<strong>$int</strong> is not a numeric value");
		}

		if( $int > $this->getTotalLines() ) {
			return 0;
		}
		else{
			return 1;
		}
	}

}
?>
